<?php
header("Location: tcc/tela_inicial/index.php");
exit();
?>
